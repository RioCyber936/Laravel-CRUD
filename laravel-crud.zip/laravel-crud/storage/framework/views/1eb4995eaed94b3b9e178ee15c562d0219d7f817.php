

<!-- Isi Title-->
<?php $__env->startSection('title','Edit Data'); ?>

<!-- Isi bagian judul halaman-->
<?php $__env->startSection('judul_halaman','Edit Data Mahasiswa'); ?>

<!-- Isi bagian konten-->
<?php $__env->startSection('konten'); ?>
<a href="/mahasiswa" class="btn btn-danger">Kembali</a>
	<br/>
	<br/>

	<?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="/mahasiswa/update" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="id" value="<?php echo e($mhs->id); ?>"><br/>
		<div class="form-group">
			<label for="namamhs">Nama</label>
			<input type="text" name="namamhs" class="form-control" required="required" value="<?php echo e($mhs->nama); ?>"> <br/>
		</div>
		<div class="form-group">
			<label for="nimmhs">NIM</label>
			<input type="number" name="nimmhs" class="form-control" required="required" value="<?php echo e($mhs->nim); ?>"> <br/>
		</div>
		<div class="form-group">
			<label for="emailmhs">E-mail</label>
			<input type="email" name="emailmhs" class="form-control" required="required" value="<?php echo e($mhs->email); ?>"> <br/>
		</div>
		<div class="form-group">
			<label for="jurusanmhs">Jurusan</label>
			<input type="text" name="jurusanmhs" class="form-control" required="required" value="<?php echo e($mhs->jurusan); ?>"> <br/>
		</div>
		<button type="submit" name="tambah" class="btn btn-primary float-right">Simpan Data</button>
	</form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/edit.blade.php ENDPATH**/ ?>